-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2023 at 02:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jhoycie`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(10, 'appliances'),
(11, 'foods'),
(12, 'beverages'),
(13, 'canned goods'),
(14, 'milk'),
(15, 'gadgets');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `units` varchar(150) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` varchar(250) NOT NULL,
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `name`, `units`, `stock`, `price`, `status`) VALUES
(12, '11', 'canned goods', '45', 159, '56', 'Active'),
(13, '11', 'bear brand', 'php', 69, '23', 'Active'),
(14, '11', 'wqdw', '34', 56, '67', 'Active'),
(15, '11', 'qwdfrwefrw', 'wesfew', 34, '67', 'Inactive'),
(16, '11', 'dgdfg', 'sg', 103, '67', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `stockhistory`
--

CREATE TABLE `stockhistory` (
  `a_Stock_ID` int(11) NOT NULL,
  `prodID` int(11) NOT NULL,
  `added_stock` int(11) NOT NULL,
  `date` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stockhistory`
--

INSERT INTO `stockhistory` (`a_Stock_ID`, `prodID`, `added_stock`, `date`) VALUES
(1, 2, 100, '03/05/2023 11:40:55 pm'),
(2, 2, 56, '03/05/2023 11:42:02 pm'),
(3, 2, 1, '04/05/2023 12:50:40 am'),
(4, 5, 45, '04/05/2023 8:20:10 pm'),
(5, 3, 2, '04/05/2023 8:21:13 pm'),
(6, 6, 69, '04/05/2023 9:34:27 pm'),
(7, 6, 34, '04/05/2023 9:50:44 pm'),
(8, 12, 69, '05/05/2023 6:45:27 am'),
(9, 16, 69, '05/05/2023 7:03:09 am'),
(10, 12, 34, '05/05/2023 8:46:48 am'),
(11, 12, 24, '05/05/2023 8:46:56 am');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockhistory`
--
ALTER TABLE `stockhistory`
  ADD PRIMARY KEY (`a_Stock_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stockhistory`
--
ALTER TABLE `stockhistory`
  MODIFY `a_Stock_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
